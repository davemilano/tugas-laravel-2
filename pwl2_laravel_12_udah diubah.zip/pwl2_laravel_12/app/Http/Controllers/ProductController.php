<?php

namespace App\Http\Controllers;

// TAMBAHKAN KEDUA BARIS INI UNTUK MENGIMPOR MODEL
use App\Models\Product;
use App\Models\Category_product;

class ProductController extends Controller
{
    public function index()
    {
        $product_model = new Product;
        $products = $product_model->get_product()->latest()->paginate(10);
        return view('products.index', compact('products'));
    }

    public function create()
    {
        $category_product = new Category_product;
        $data['categories'] = $category_product->get_category_product()->get();
        return view('products.create', compact('data'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'image'               => 'required|image|mimes:jpeg,jpg,png|max:2048',
            'title'               => 'required|min:5',
            'product_category_id' => 'required|integer',
            'description'         => 'required|min:10',
            'price'               => 'required|numeric',
            'stock'               => 'required|numeric'
        ]);

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $image->storeAs('public/images', $image->hashName());

            $product = new Product;
            $product->storeProduct($request, $image);

            return redirect()->route('products.index')->with(['success' => 'Data Berhasil Disimpan!']);
        }
        
        return redirect()->route('products.index')->with(['error' => 'Gagal Mengunggah Gambar.']);
    }
}