<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TestController extends Controller
{
    public function index()
    {
        return 'Halo, ini Test Controller. Jika ini muncul, routing dasar Anda bekerja.';
    }
}