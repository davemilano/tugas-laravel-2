<?php

use Illuminate\Support\Facades\Route;

// Di sintaks lama, kita tidak perlu 'use' statement untuk controller di sini.

Route::get('/', function () {
    return view('welcome');
});

// Ini sintaks yang benar untuk versi Laravel Anda: 'NamaController@namaMethod'
Route::get('/test', 'TestController@index');

// Untuk route resource, cukup gunakan nama controller-nya sebagai string
Route::resource('/products', 'ProductController');