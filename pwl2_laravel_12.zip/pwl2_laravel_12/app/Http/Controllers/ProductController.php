<?php

namespace App\Http\Controllers;

use app\Models\Product;

use Illuminate\view\View;

use Illuminate\Http\Request;

use App\Models\Category_product;
use App\Product as AppProduct;
use Illuminate\Http\RedirectResponse;

use Illuminate\Support\Facades\Storage;


class ProductController extends Controller
{
    /**
     * index
     * 
     * @return void
     */
    public function index() : View
    {
        $product = new product;
        $product = $product->get_product()->latest()->paginate(10);

        return View ('products.index', compact ('products'));
    }

    
    /**
     * create
     * 
     * @return view
     */
    public function create() : View
    {
        $Category_product = new Category_product;

        $data ['categories']= $Category_product->get_Category_product()->get();

        return View ('products.create', compact ('data'));
    }

    /**
     * store
     * 
     * @param mixed $request
     * @return RedirectResponse
     */
    public function store(Request $request): RedirectResponse
    {
        //var_dump($request);exit;
        //validate form
        $validatedData = $request->validate([
            'image'                    => 'require|image|mimes:jpeg,jpg,png|max:2048',
            'title'                    => 'required|min:5',
            'product_category_id'      => 'required|integer',
            'description'              => 'required|min:10',
            'price'                    => 'required|numeric',
            'stock'                    => 'required|numeric'
        ])

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $store_image = $image->store('image','public');//simpan gambar ke folder penyimpanan

            $product = new product;
            $insert_product = $product->storeProduct($request, $image);

            return redirect()->route('product.index')->with(['success' => 'Data Berhasil Disimpan!']);
        }

        return redirect()->route('product.index')->with(['error' => 'Failed To Upload Image (request).']);

    }





}
