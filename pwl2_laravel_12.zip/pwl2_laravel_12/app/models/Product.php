<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    public function get_product()
{   
    // get all products
    $sql = $this->select("products.*","category_product.product_category_name as product_category_name","supplier.supplier_name")
        ->leftjoin('category_product', 'category_product.id', '=', 'products.product_category_id')
        ->leftjoin('supplier', 'supplier.id', '=', 'products.supplier_id');

    return $sql;
}
    /**
     * fillable
     * 
     * @var array
     */
    protected $fillable = [
        'image',
        'title',
        'product_category_id',
        'description',
        'price',
        'stock',
    ];

    public static function storeProduct ($request,$image)
{
    return Self::create([
        'image'                    => $image -> hashName(),
        'title'                    => $request->title,
        'product_category_id'      => $request->product_category_id,
        'description'              => $request->description,
        'price'                    => $request->price,
        'stock'                    => $request->stock,
    ]);
}


}



